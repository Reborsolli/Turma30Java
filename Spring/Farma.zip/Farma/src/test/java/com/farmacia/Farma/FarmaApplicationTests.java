package com.farmacia.Farma;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FarmaApplicationTests {

	@Test
	void contextLoads() {
	}

}
